# The-Sparks-Foundation
Task 1 - Prediction Using Supervised Machine Learning 

Task 2 - Prediction Using Unsupervised Machine Learning - Iris (Dataset :- https://bit.ly/3kXTdox )

Task 3 - Exploratory Data Analysis - Retail  (Dataset:- SampleSuperstore.csv(https://bit.ly/3i4rbWl))

Task 4 - Exploratory Data Analysis - Terrorism (Dataset :- globalterrorismdb_0718dist.csv (https://bit.ly/2TK5Xn5))

Task 5 - Exploratory Data Analysis - Sports (Dataset :- Indian Premier League (https://bit.ly/34SRn3b))

Task 6 - Prediction Using Decision Tree Classifier (Dataset :- iris.csv (https://bit.ly/3kXTdox))
